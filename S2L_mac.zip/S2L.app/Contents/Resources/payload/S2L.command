#!/bin/bash
cd "$(dirname "$0")"
exec bash ./install_and_run_local.sh
